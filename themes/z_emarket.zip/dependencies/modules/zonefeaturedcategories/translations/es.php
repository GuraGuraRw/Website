<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_4d58bb8bb20bdb2f1f1c9e0d20bebdba'] = 'Z.One - Categorías destacadas';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_facf8c14394bdcb0aa370b535a81caa7'] = 'Muestra las categorías destacadas en la página de inicio.';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_c888438d14855d7d96a2724ee9c306bd'] = 'Ajustes actualizados';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_72b4313971e54af2e789659c8914fe2d'] = 'Categoría y Miniaturas';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_d151787349318564a35de12bea9c49f5'] = 'Categoría, Miniaturas y Subcategorías';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_008f9b95f3cc15d57768e083d85052e4'] = '¡No se ha encontrado!';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_2b492a907cdaba51ee76f6f6a1058291'] = 'Activar el Slider';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_d607e9294aa8e2126d973db8b5a18d4b'] = 'Activar el Slider en versión móvil';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_ed2dbc5b1b6866f8e3c9ebf1b17c29c9'] = 'Categorías por fila';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_d88c2d574db3b95610edce7cbafb9463'] = 'El número de bloques de categorías por línea.';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_f722cb1ee3e9fbb1f8625f1dbc0db97e'] = 'Tipo de imagen de la categoría';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_c755dc2ca8c7e72f1f20ada44fcc00f6'] = 'Selección de la categoría';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_057f1d38f1c82e6af159d26d65f389aa'] = 'Estilo de diseño';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_4c34e5a9c09c06d57af8683b3123aae8'] = 'Número de subcategorías';
$_MODULE['<{zonefeaturedcategories}prestashop>zonefeaturedcategories_a9d3b3b0a8be2a4d0d6a86467c687807'] = 'Limita el número de subcategorías de una categoría. Si se establece en cero, no se impone ningún límite.';
