<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_7092075cf191216ab3c270966a6c9282'] = 'Z.One - Brand Logo';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_ca779fb9b81bb4d54d2774921b827851'] = 'Visualizza il blocco dei produttori con il logo';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_4d57e392fd8b53afcdaf11222cc0b5f3'] = 'Impostazioni del blocco';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_2b492a907cdaba51ee76f6f6a1058291'] = 'Attiva lo slider';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_d607e9294aa8e2126d973db8b5a18d4b'] = 'Attiva lo slider su dispositivi mobili';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_8316800d3cdec385e5e894ffac90ef4c'] = 'Autoplay slider';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_1d2bb7d0c1498694545cf01a2a41e634'] = 'Mostra nome produttore';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_8146ed5a1e81f7d9ff604a16a3830676'] = 'Mostra solo i produttori con un logo';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_2b7e3f7e1713858e0e1789ee29892eb2'] = 'Mostra solo i produttori con dei prodotti';
