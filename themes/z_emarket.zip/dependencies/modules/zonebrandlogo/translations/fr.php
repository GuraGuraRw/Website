<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_7092075cf191216ab3c270966a6c9282'] = 'Z.One - Logo de Marque';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_ca779fb9b81bb4d54d2774921b827851'] = 'Affiche le block des Fabricants';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_c888438d14855d7d96a2724ee9c306bd'] = 'Configuration mise à jour';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_4d57e392fd8b53afcdaf11222cc0b5f3'] = 'Configuration du Block';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_2b492a907cdaba51ee76f6f6a1058291'] = 'Activer le Slider';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_d607e9294aa8e2126d973db8b5a18d4b'] = 'Activer le Slider sur Mobile';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_8316800d3cdec385e5e894ffac90ef4c'] = 'Lecture automatique du Slider';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_1d2bb7d0c1498694545cf01a2a41e634'] = 'Afficher le Nom du Fabricant';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_8146ed5a1e81f7d9ff604a16a3830676'] = 'Afficher uniquement les Fabricants avec un Logo';
$_MODULE['<{zonebrandlogo}prestashop>zonebrandlogo_2b7e3f7e1713858e0e1789ee29892eb2'] = 'Afficher uniquement les Fabricants avec des produits';
