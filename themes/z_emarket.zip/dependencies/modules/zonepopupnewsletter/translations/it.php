<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_c026706b23d1b7a71306a47005db4b4a'] = 'Z.One - Popup Newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_cb57b31c3e4d83c9655979097799df06'] = 'Visualizza un popup newsletter al caricamento della pagina.';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_070e16b4f77b90e802f789b5be583cfa'] = 'Errore di caricamento del file';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_6b7a0b1b2d1735dea5c9ebe049a9c7fb'] = 'Le impostazioni sono state aggiornate correttamente.';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_2a322b6edf581b8e48aaf5dbbedacd11'] = 'Si è verificato un errore durante il tentativo di salvataggio delle impostazioni.';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_03da62e936d9e4a7f22c4fcaddeb8571'] = 'Popup Newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_0fb8cc91b73589a73e6ae029bc2dd517'] = 'Larghezza popup';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_0ac706a9d2a1d490346e6fd9fea58ad3'] = 'Altezza popup';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_75e7422f2fe253fc69d3f6c148d197ee'] = 'Colore di fondo';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_691a33081491c169ebc3fa13370a857a'] = 'Colore di fondo del popup newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_abd809c9e3c1c08e97740f86b8ceabfb'] = 'Immagine di sfondo';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_888565f7c63bf812a6d3bbd8ffd6ae4e'] = 'Carica una nuova immagine di sfondo per il popup newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_9d2a80d1adb7fcc61fad739b401134a4'] = 'Le dimensioni raccomandate sono 670x500 pixel';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_a4a067df2a4c17df660a322774fa5a2e'] = 'Durata Cookie';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_44fdec47036f482b68b748f9d786801b'] = 'giorni';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_33cc5da0686ab3e1c6f4f2f9de894255'] = 'Per quanto tempo devono essere conservati i cookie?';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_2b5af8c53a0a4b6ac7bff6c607d8a055'] = '0 = alla chiusura del browser';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_08a69cef5856a75bc70cc91ea5d28d5a'] = 'Modulo di iscrizione alla newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_f15c1cae7882448b3fb0404682e17e61'] = 'Contenuto';
