<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_c026706b23d1b7a71306a47005db4b4a'] = 'Z.One - Popup Newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_cb57b31c3e4d83c9655979097799df06'] = 'Affiche une popup de Newsletter lors du chargement de la page.';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_070e16b4f77b90e802f789b5be583cfa'] = 'Erreur lors de l\'ajouter du fichier.';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_6b7a0b1b2d1735dea5c9ebe049a9c7fb'] = 'La configuration a été mise à jour avec succès.';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_2a322b6edf581b8e48aaf5dbbedacd11'] = 'Une erreur est survenue lors de l\'enregistrement de la configuration.';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_03da62e936d9e4a7f22c4fcaddeb8571'] = 'Popup Newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_0fb8cc91b73589a73e6ae029bc2dd517'] = 'Largeur de la Popup';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_0ac706a9d2a1d490346e6fd9fea58ad3'] = 'Hauteur de la Popup';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_75e7422f2fe253fc69d3f6c148d197ee'] = 'Couleur de Fond';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_691a33081491c169ebc3fa13370a857a'] = 'Couleur de fond de Popup Newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_abd809c9e3c1c08e97740f86b8ceabfb'] = 'Image de Fond';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_888565f7c63bf812a6d3bbd8ffd6ae4e'] = 'Ajouter une image de fond pour Pop Newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_9d2a80d1adb7fcc61fad739b401134a4'] = 'Les dimensions recommandées sont 670x500 pixels';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_a4a067df2a4c17df660a322774fa5a2e'] = 'Délais du Cookie';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_44fdec47036f482b68b748f9d786801b'] = 'jours';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_33cc5da0686ab3e1c6f4f2f9de894255'] = 'Combien de temps le cookie doit être stocké ?';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_2b5af8c53a0a4b6ac7bff6c607d8a055'] = '0 = quand le navigateur est fermé';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_08a69cef5856a75bc70cc91ea5d28d5a'] = 'Formulaire d\'inscription à la Newsletter';
$_MODULE['<{zonepopupnewsletter}prestashop>zonepopupnewsletter_f15c1cae7882448b3fb0404682e17e61'] = 'Contenu';
