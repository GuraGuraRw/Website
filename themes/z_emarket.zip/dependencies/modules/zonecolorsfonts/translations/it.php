<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_cece1beb9d58f211cb78d0469c46766b'] = 'Z.One - Colori e caratteri';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_a7de2469d58f71915289e5756e069f48'] = 'Personalizza colori e caratteri del tema ZOne.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_3aa5a4bfd2885710851e62bc89640278'] = '% ripristinata correttamente.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_2a322b6edf581b8e48aaf5dbbedacd11'] = 'Si è verificato un errore durante il tentativo di salvataggio delle impostazioni.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_94c76dac6cbce0c529c309b10cbadee6'] = '% aggiornata correttamente.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_e6f4c3ea31518f7d5aa54babc2b2b940'] = 'Il CSS personalizzato è stato salvato correttamente.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_7e06d01b8229c70861d011f719bb2439'] = 'Si è verificato un errore durante il tentativo di salvataggio del CSS personalizzato.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_21cd048124ebd04b0be3170e522dcba1'] = 'Caratteri più popolari';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_59edad035894a7fec5169a34bfbe61d2'] = 'Copia il nome del carattere e incollalo nell\'opzione carattere';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_65fad9602632352f603f3903004196cd'] = 'Importa caratteri';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_2f68179c5f99c1430e413f2057243901'] = 'Aggiungi il link al foglio di stile nel tuo sito web';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_f5c1064ebd117f58b45dceb0ca6cacaf'] = 'Anteprima';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_0ee884fa0506a3ed970caf2b5281e718'] = 'Visualizza l\'anteprima dei colori generali sul front-end.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_205f915260f7e8910388b7236aa7ba5a'] = 'Ripristina impostazioni predefinite';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_42e6feb7f76e910efcda54034ecc83ce'] = 'CSS personalizzato';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_c6f6b02e6fe1e321d4f0c560dca1d2d0'] = 'Aggiungi un foglio di stile specifico per il tuo sito.';
$_MODULE['<{zonecolorsfonts}prestashop>settings_form_42e6feb7f76e910efcda54034ecc83ce'] = 'CSS personalizzato';
