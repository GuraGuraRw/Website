<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_cece1beb9d58f211cb78d0469c46766b'] = 'Z.One - Couleurs et Polices';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_a7de2469d58f71915289e5756e069f48'] = 'Personnalisez les couleurs et les polices du thème ZOne';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_3aa5a4bfd2885710851e62bc89640278'] = '%s réinitialisé avec succès';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_2a322b6edf581b8e48aaf5dbbedacd11'] = 'Une erreur est survenue lors de la sauvegarde des Paramètres';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_94c76dac6cbce0c529c309b10cbadee6'] = '%s mis à jour avec succès';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_e6f4c3ea31518f7d5aa54babc2b2b940'] = 'Le CSS personnalisé a été sauvegardée avec succès.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_7e06d01b8229c70861d011f719bb2439'] = 'Une erreur est survenue lors de la sauvegarde du CSS personnalisé';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_21cd048124ebd04b0be3170e522dcba1'] = 'Polices les plus populaires';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_59edad035894a7fec5169a34bfbe61d2'] = 'Copiez le nom de la police et collez-le dans le champ police';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_65fad9602632352f603f3903004196cd'] = 'Importer des polices';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_2f68179c5f99c1430e413f2057243901'] = 'Ajouter le lien de la feuille de style sur votre site';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_f5c1064ebd117f58b45dceb0ca6cacaf'] = 'Aperçu en live';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_0ee884fa0506a3ed970caf2b5281e718'] = 'Afficher l\'aperçu en live des couleurs générales sur le front-end';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_205f915260f7e8910388b7236aa7ba5a'] = 'Réinitialiser avec les options par défaut';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_42e6feb7f76e910efcda54034ecc83ce'] = 'CSS personnalisé';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_c6f6b02e6fe1e321d4f0c560dca1d2d0'] = 'Ajouter une feuille de style spécifique pour votre site.';
$_MODULE['<{zonecolorsfonts}prestashop>settings_form_42e6feb7f76e910efcda54034ecc83ce'] = 'CSS personnalisé';
