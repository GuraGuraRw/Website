<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_cece1beb9d58f211cb78d0469c46766b'] = ' Z.One - Colores y fuentes';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_a7de2469d58f71915289e5756e069f48'] = 'Personalizar los colores y fuentes del tema.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_3aa5a4bfd2885710851e62bc89640278'] = '%s restablecido con éxito.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_2a322b6edf581b8e48aaf5dbbedacd11'] = 'Se produjo un error al intentar guardar los ajustes.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_94c76dac6cbce0c529c309b10cbadee6'] = '%s actualizado con éxito.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_e6f4c3ea31518f7d5aa54babc2b2b940'] = 'El CSS personalizado se ha guardado con éxito.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_7e06d01b8229c70861d011f719bb2439'] = 'Se produjo un error al intentar guardar el CSS personalizado.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_21cd048124ebd04b0be3170e522dcba1'] = 'Las fuentes más populares';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_59edad035894a7fec5169a34bfbe61d2'] = 'Copia el nombre de la fuente y pégalo en la opción de fuentes';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_65fad9602632352f603f3903004196cd'] = 'Importar fuentes';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_2f68179c5f99c1430e413f2057243901'] = 'Añadir el enlace de la hoja de estilos a tu página web';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_f5c1064ebd117f58b45dceb0ca6cacaf'] = 'Vista previa en directo';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_0ee884fa0506a3ed970caf2b5281e718'] = 'Mostrar la vista previa de los Colores Generales en el front-end.';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_205f915260f7e8910388b7236aa7ba5a'] = 'Restablecer los valores por defecto';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_42e6feb7f76e910efcda54034ecc83ce'] = 'CSS personalizado';
$_MODULE['<{zonecolorsfonts}prestashop>zonecolorsfonts_c6f6b02e6fe1e321d4f0c560dca1d2d0'] = 'Añade una hoja de estilos especial a tu página web.';
$_MODULE['<{zonecolorsfonts}prestashop>settings_form_42e6feb7f76e910efcda54034ecc83ce'] = 'CSS personalizado';
